import pathlib
import re

import setuptools

BASE = pathlib.Path(__file__).parent

readme_file = BASE / "README.md"
version_file = BASE / "aiosnmp" / "__init__.py"

version = re.findall(r'^__version__ = "(.+?)"$', version_file.read_text("utf-8"), re.M)[0]

setuptools.setup(
    name="aiosnmp",
    packages=["aiosnmp"],
    url="https://github.com/hh-h/aiosnmp",
    license="MIT",
    author="Valetov Konstantin",
    author_email="forjob@thetrue.name",
    description="asyncio SNMP client",
    classifiers=[
        "License :: OSI Approved :: MIT License",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Framework :: AsyncIO",
    ],
    python_requires=">=3",
    install_requires=[],
    extras_require={
        'dev': ['build', 'twine', 'pycodestyle'],
    },
    package_data={},
    data_files=[],
)
