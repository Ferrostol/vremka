import logging

logger = logging.getLogger("aiosnmp")
